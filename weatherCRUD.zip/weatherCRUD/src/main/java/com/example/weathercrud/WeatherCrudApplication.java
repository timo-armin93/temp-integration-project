package com.example.weathercrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeatherCrudApplication {

    public static void main(String[] args) {
        SpringApplication.run(WeatherCrudApplication.class, args);
    }

}
